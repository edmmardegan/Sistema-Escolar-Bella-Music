// Local: src/usuarios/users.service.ts
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from '../entities/user.entity';
import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {
  constructor(
    @InjectRepository(User)
    private usersRepository: Repository<User>,
  ) {}

  // 1. Listar todos os usuários (para a tabela do frontend)
  async findAll() {
    return this.usersRepository.find({
      // ADICIONE O 'id' AQUI se ele não estiver
      select: ['id', 'nome', 'email', 'role', 'primeiroAcesso'],
      order: { nome: 'ASC' },
    });
  }

  // 2. Criar novo (já com sua lógica de senha e primeiro acesso)
  async create(userData: any) {
    const salt = await bcrypt.genSalt();
    const hashedPassword = await bcrypt.hash(userData.senha || '123456', salt);

    const newUser = this.usersRepository.create({
      nome: userData.nome,
      email: userData.email,
      username: userData.email,
      senha: hashedPassword,
      role: userData.role || 'user',
      primeiroAcesso: true,
    });

    return this.usersRepository.save(newUser);
  }

  // 3. Atualizar dados gerais (Editar)
  async update(id: number, userData: any) {
    // Se a senha foi enviada no formulário de edição, precisamos hashear
    if (userData.senha) {
      const salt = await bcrypt.genSalt();
      userData.senha = await bcrypt.hash(userData.senha, salt);
    }

    return this.usersRepository.update(id, {
      nome: userData.nome,
      email: userData.email,
      role: userData.role,
      // Se houver senha nova, atualiza, senão ignora
      ...(userData.senha && { senha: userData.senha }),
    });
  }

  // 4. Reset Administrativo (Botão de Chave)
  // 1. AÇÃO DO ADMIN: Reseta a senha e OBRIGA a troca (true)
  async resetPasswordAdmin(id: number, novaSenha: string) {
    const salt = await bcrypt.genSalt();
    const hashedPassword = await bcrypt.hash(novaSenha, salt);
    return await this.usersRepository.update(id, {
      senha: hashedPassword,
      primeiroAcesso: true,
    });
  }

  // 2. AÇÃO DO USUÁRIO: Troca a própria senha e LIBERA o acesso (false)
  async updateOwnPassword(id: number, novaSenha: string) {
    const salt = await bcrypt.genSalt();
    const hashedPassword = await bcrypt.hash(novaSenha, salt);
    return await this.usersRepository.update(id, {
      senha: hashedPassword,
      primeiroAcesso: false,
    });
  }
  // 5. Deletar
  async remove(id: number) {
    return this.usersRepository.delete(id);
  }

  // --- Funções que você já tinha ---

  async updatePassword(id: number, novaSenha: string) {
    const salt = await bcrypt.genSalt();
    const hashedPassword = await bcrypt.hash(novaSenha, salt);

    return this.usersRepository.update(id, {
      senha: hashedPassword,
      primeiroAcesso: false,
    });
  }

  async findByEmail(email: string): Promise<User | null> {
    return this.usersRepository.findOne({ where: { email } });
  }

  async findOne(identificador: string): Promise<User | null> {
    return this.usersRepository.findOne({
      where: [{ email: identificador }, { username: identificador }],
    });
  }
}
