// Local: src/usuarios/users.controller.ts
import {
  Controller,
  Get,
  Post,
  Body,
  Put,
  Param,
  Delete,
  UseGuards,
  Patch,
} from '@nestjs/common';
import { UsersService } from './users.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@UseGuards(JwtAuthGuard)
@Controller('usuarios')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Get()
  async findAll() {
    return this.usersService.findAll();
  }

  @Post()
  async create(@Body() userData: any) {
    return this.usersService.create(userData);
  }

  @Put(':id')
  async update(@Param('id') id: number, @Body() userData: any) {
    return this.usersService.update(id, userData);
  }

  @Delete(':id')
  async remove(@Param('id') id: number) {
    return this.usersService.remove(id);
  }

  @Patch(':id/reset-password-admin') // Rota que o Admin clica na tabela
  async resetAdmin(
    @Param('id') id: string,
    @Body('novaSenha') novaSenha: string,
  ) {
    return this.usersService.resetPasswordAdmin(+id, novaSenha);
  }

  @Patch(':id/update-own-password') // Rota que o usuário usa na tela de 1º acesso
  async updateOwn(
    @Param('id') id: string,
    @Body('novaSenha') novaSenha: string,
  ) {
    return this.usersService.updateOwnPassword(+id, novaSenha);
  }
}
